#Author-
#Description-
"""
import adsk.core, adsk.fusion, adsk.cam, traceback

def run(context):
    ui = None
    try:
        app = adsk.core.Application.get()
        ui  = app.userInterface
        ui.messageBox('Hello script')

    except:
        if ui:
            ui.messageBox('Failed:\n{}'.format(traceback.format_exc())) 
"""
import adsk.core, adsk.fusion, adsk.cam, traceback

def run(context):
    ui = None
    try:
        app = adsk.core.Application.get()
        ui = app.userInterface
        design = app.activeProduct

        # 現在の選択セットを取得
        selection = ui.activeSelections
        selected_faces = []

        # 既に面が選択されているかを確認
        if selection.count > 0:
            for i in range(selection.count):
                selected_entity = selection.item(i).entity
                if isinstance(selected_entity, adsk.fusion.BRepFace):
                    selected_faces.append(selected_entity)

        # 面が選択されていない場合、新たに面を選択
        if not selected_faces:
            ui.messageBox('合計表面積を計算する面を選択してください。面の選択を完了するには「Esc」キーを押してください。')
            
            while True:
                try:
                    # 面を選択する（キャンセルすると None が返る）
                    selected_entity = ui.selectEntity('面を選択してください（完了するには Esc キーを押してください）', 'Faces')
                    if not selected_entity:  # Esc キーが押された場合に選択を終了
                        break
                    # 選択された面をリストに追加
                    if isinstance(selected_entity.entity, adsk.fusion.BRepFace):
                        selected_faces.append(selected_entity.entity)
                except RuntimeError as e:
                    # 選択がキャンセルされた場合やエラーが発生した場合は次のステップへ
                    if 'InternalValidationError' in str(e):
                        break
                    else:
                        ui.messageBox('面の選択中にエラーが発生しました: {}'.format(e))
                        return

        # 選択された面がない場合は終了
        if not selected_faces:
            ui.messageBox('面が選択されていません。')
            return
        
        # 合計表面積を計算
        total_area = 0.0
        for face in selected_faces:
            total_area += face.area

        

        # 表面積を 1.2345 * 10^n の形に調整
        p = 2
        while not 1 < total_area < 10 and total_area > 1:
            total_area = total_area / 10
            p += 1
        while not 1 < total_area < 10 and total_area < 10:
            total_area = total_area * 10
            p -= 1
            
        # 合計表面積を表示
        ui.messageBox(f'選択された面の合計表面積は {total_area:.3f} * 10^{p}\n {total_area:.5f} * 10^{p}')
        

    except:
        if ui:
            ui.messageBox('スクリプトの実行中にエラーが発生しました:\n{}'.format(traceback.format_exc()))


